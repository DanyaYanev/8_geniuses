﻿namespace расширение_формы
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanelAll = new System.Windows.Forms.TableLayoutPanel();
            this.Place = new System.Windows.Forms.GroupBox();
            this.Form = new System.Windows.Forms.GroupBox();
            this.SizeForm = new System.Windows.Forms.GroupBox();
            this.Resolution = new System.Windows.Forms.GroupBox();
            this.GrExit = new System.Windows.Forms.GroupBox();
            this.UpLeft = new System.Windows.Forms.Button();
            this.Up = new System.Windows.Forms.Button();
            this.UpRight = new System.Windows.Forms.Button();
            this.Left = new System.Windows.Forms.Button();
            this.Centre = new System.Windows.Forms.Button();
            this.Right = new System.Windows.Forms.Button();
            this.DownLeft = new System.Windows.Forms.Button();
            this.Down = new System.Windows.Forms.Button();
            this.DownRight = new System.Windows.Forms.Button();
            this.MaxWin = new System.Windows.Forms.Button();
            this.Back = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.Standart = new System.Windows.Forms.Button();
            this.Resolution1000 = new System.Windows.Forms.Button();
            this.Resolution1200 = new System.Windows.Forms.Button();
            this.Ban = new System.Windows.Forms.Button();
            this.Plus = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.FormResol = new System.Windows.Forms.TextBox();
            this.DeskResol = new System.Windows.Forms.TextBox();
            this.ResForm = new System.Windows.Forms.Label();
            this.DesForm = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.Exit = new System.Windows.Forms.Button();
            this.tableLayoutPanelAll.SuspendLayout();
            this.Place.SuspendLayout();
            this.Form.SuspendLayout();
            this.SizeForm.SuspendLayout();
            this.Resolution.SuspendLayout();
            this.GrExit.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanelAll
            // 
            this.tableLayoutPanelAll.ColumnCount = 3;
            this.tableLayoutPanelAll.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAll.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAll.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanelAll.Controls.Add(this.Place, 0, 0);
            this.tableLayoutPanelAll.Controls.Add(this.Form, 1, 0);
            this.tableLayoutPanelAll.Controls.Add(this.SizeForm, 1, 1);
            this.tableLayoutPanelAll.Controls.Add(this.Resolution, 2, 0);
            this.tableLayoutPanelAll.Controls.Add(this.GrExit, 2, 1);
            this.tableLayoutPanelAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelAll.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelAll.Name = "tableLayoutPanelAll";
            this.tableLayoutPanelAll.RowCount = 2;
            this.tableLayoutPanelAll.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAll.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelAll.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanelAll.TabIndex = 0;
            // 
            // Place
            // 
            this.Place.Controls.Add(this.DownRight);
            this.Place.Controls.Add(this.Down);
            this.Place.Controls.Add(this.DownLeft);
            this.Place.Controls.Add(this.Right);
            this.Place.Controls.Add(this.Centre);
            this.Place.Controls.Add(this.Left);
            this.Place.Controls.Add(this.UpRight);
            this.Place.Controls.Add(this.Up);
            this.Place.Controls.Add(this.UpLeft);
            this.Place.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Place.Location = new System.Drawing.Point(15, 15);
            this.Place.Margin = new System.Windows.Forms.Padding(15);
            this.Place.Name = "Place";
            this.tableLayoutPanelAll.SetRowSpan(this.Place, 2);
            this.Place.Size = new System.Drawing.Size(236, 420);
            this.Place.TabIndex = 0;
            this.Place.TabStop = false;
            this.Place.Text = "Положение на экране";
            // 
            // Form
            // 
            this.Form.Controls.Add(this.tableLayoutPanel2);
            this.Form.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Form.Location = new System.Drawing.Point(281, 15);
            this.Form.Margin = new System.Windows.Forms.Padding(15);
            this.Form.Name = "Form";
            this.Form.Size = new System.Drawing.Size(236, 195);
            this.Form.TabIndex = 1;
            this.Form.TabStop = false;
            this.Form.Text = "Состояние формы";
            this.Form.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // SizeForm
            // 
            this.SizeForm.Controls.Add(this.tableLayoutPanel3);
            this.SizeForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SizeForm.Location = new System.Drawing.Point(281, 240);
            this.SizeForm.Margin = new System.Windows.Forms.Padding(15);
            this.SizeForm.Name = "SizeForm";
            this.SizeForm.Size = new System.Drawing.Size(236, 195);
            this.SizeForm.TabIndex = 2;
            this.SizeForm.TabStop = false;
            this.SizeForm.Text = "Размер формы";
            this.SizeForm.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // Resolution
            // 
            this.Resolution.Controls.Add(this.tableLayoutPanel1);
            this.Resolution.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Resolution.Location = new System.Drawing.Point(547, 15);
            this.Resolution.Margin = new System.Windows.Forms.Padding(15);
            this.Resolution.Name = "Resolution";
            this.Resolution.Size = new System.Drawing.Size(238, 195);
            this.Resolution.TabIndex = 3;
            this.Resolution.TabStop = false;
            this.Resolution.Text = "Разрешение";
            this.Resolution.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // GrExit
            // 
            this.GrExit.Controls.Add(this.tableLayoutPanel4);
            this.GrExit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GrExit.Location = new System.Drawing.Point(547, 240);
            this.GrExit.Margin = new System.Windows.Forms.Padding(15);
            this.GrExit.Name = "GrExit";
            this.GrExit.Size = new System.Drawing.Size(238, 195);
            this.GrExit.TabIndex = 4;
            this.GrExit.TabStop = false;
            this.GrExit.Text = "Выход";
            this.GrExit.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // UpLeft
            // 
            this.UpLeft.Location = new System.Drawing.Point(-1, 88);
            this.UpLeft.Name = "UpLeft";
            this.UpLeft.Size = new System.Drawing.Size(75, 67);
            this.UpLeft.TabIndex = 0;
            this.UpLeft.UseVisualStyleBackColor = true;
            // 
            // Up
            // 
            this.Up.Location = new System.Drawing.Point(80, 88);
            this.Up.Name = "Up";
            this.Up.Size = new System.Drawing.Size(75, 67);
            this.Up.TabIndex = 1;
            this.Up.UseVisualStyleBackColor = true;
            // 
            // UpRight
            // 
            this.UpRight.Location = new System.Drawing.Point(161, 88);
            this.UpRight.Name = "UpRight";
            this.UpRight.Size = new System.Drawing.Size(75, 67);
            this.UpRight.TabIndex = 2;
            this.UpRight.UseVisualStyleBackColor = true;
            // 
            // Left
            // 
            this.Left.Location = new System.Drawing.Point(-1, 176);
            this.Left.Name = "Left";
            this.Left.Size = new System.Drawing.Size(75, 67);
            this.Left.TabIndex = 3;
            this.Left.UseVisualStyleBackColor = true;
            this.Left.Click += new System.EventHandler(this.Left_Click);
            // 
            // Centre
            // 
            this.Centre.Location = new System.Drawing.Point(80, 176);
            this.Centre.Name = "Centre";
            this.Centre.Size = new System.Drawing.Size(75, 67);
            this.Centre.TabIndex = 4;
            this.Centre.UseVisualStyleBackColor = true;
            // 
            // Right
            // 
            this.Right.Location = new System.Drawing.Point(161, 176);
            this.Right.Name = "Right";
            this.Right.Size = new System.Drawing.Size(75, 67);
            this.Right.TabIndex = 5;
            this.Right.UseVisualStyleBackColor = true;
            // 
            // DownLeft
            // 
            this.DownLeft.Location = new System.Drawing.Point(-1, 263);
            this.DownLeft.Name = "DownLeft";
            this.DownLeft.Size = new System.Drawing.Size(75, 67);
            this.DownLeft.TabIndex = 6;
            this.DownLeft.UseVisualStyleBackColor = true;
            // 
            // Down
            // 
            this.Down.Location = new System.Drawing.Point(80, 263);
            this.Down.Name = "Down";
            this.Down.Size = new System.Drawing.Size(75, 67);
            this.Down.TabIndex = 7;
            this.Down.UseVisualStyleBackColor = true;
            // 
            // DownRight
            // 
            this.DownRight.Location = new System.Drawing.Point(161, 263);
            this.DownRight.Name = "DownRight";
            this.DownRight.Size = new System.Drawing.Size(75, 67);
            this.DownRight.TabIndex = 8;
            this.DownRight.UseVisualStyleBackColor = true;
            // 
            // MaxWin
            // 
            this.MaxWin.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MaxWin.Location = new System.Drawing.Point(3, 3);
            this.MaxWin.Name = "MaxWin";
            this.MaxWin.Size = new System.Drawing.Size(224, 52);
            this.MaxWin.TabIndex = 0;
            this.MaxWin.Text = "Развернуть";
            this.MaxWin.UseVisualStyleBackColor = true;
            // 
            // Back
            // 
            this.Back.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Back.Location = new System.Drawing.Point(3, 61);
            this.Back.Name = "Back";
            this.Back.Size = new System.Drawing.Size(224, 52);
            this.Back.TabIndex = 1;
            this.Back.Text = "Восстановить размер";
            this.Back.UseVisualStyleBackColor = true;
            // 
            // Close
            // 
            this.Close.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Close.Location = new System.Drawing.Point(3, 119);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(224, 54);
            this.Close.TabIndex = 2;
            this.Close.Text = "Свернуть";
            this.Close.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.Close, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.MaxWin, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.Back, 0, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(230, 176);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.56522F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.43478F));
            this.tableLayoutPanel3.Controls.Add(this.Resolution1000, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.Resolution1200, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.Ban, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.Plus, 0, 4);
            this.tableLayoutPanel3.Controls.Add(this.Minus, 1, 4);
            this.tableLayoutPanel3.Controls.Add(this.Standart, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 5;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(230, 176);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // Standart
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.Standart, 2);
            this.Standart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Standart.Location = new System.Drawing.Point(3, 3);
            this.Standart.Name = "Standart";
            this.Standart.Size = new System.Drawing.Size(224, 29);
            this.Standart.TabIndex = 0;
            this.Standart.Text = "Стандартный";
            this.Standart.UseVisualStyleBackColor = true;
            // 
            // Resolution1000
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.Resolution1000, 2);
            this.Resolution1000.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Resolution1000.Location = new System.Drawing.Point(3, 38);
            this.Resolution1000.Name = "Resolution1000";
            this.Resolution1000.Size = new System.Drawing.Size(224, 29);
            this.Resolution1000.TabIndex = 1;
            this.Resolution1000.Text = "1000 x 500";
            this.Resolution1000.UseVisualStyleBackColor = true;
            // 
            // Resolution1200
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.Resolution1200, 2);
            this.Resolution1200.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Resolution1200.Location = new System.Drawing.Point(3, 73);
            this.Resolution1200.Name = "Resolution1200";
            this.Resolution1200.Size = new System.Drawing.Size(224, 29);
            this.Resolution1200.TabIndex = 2;
            this.Resolution1200.Text = "1280 x 960";
            this.Resolution1200.UseVisualStyleBackColor = true;
            // 
            // Ban
            // 
            this.tableLayoutPanel3.SetColumnSpan(this.Ban, 2);
            this.Ban.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Ban.Location = new System.Drawing.Point(3, 108);
            this.Ban.Name = "Ban";
            this.Ban.Size = new System.Drawing.Size(224, 29);
            this.Ban.TabIndex = 3;
            this.Ban.Text = "Запрет на изменение размера";
            this.Ban.UseVisualStyleBackColor = true;
            // 
            // Plus
            // 
            this.Plus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Plus.Location = new System.Drawing.Point(3, 143);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(107, 30);
            this.Plus.TabIndex = 4;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = true;
            // 
            // Minus
            // 
            this.Minus.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Minus.Location = new System.Drawing.Point(116, 143);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(111, 30);
            this.Minus.TabIndex = 5;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = true;
            // 
            // FormResol
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.FormResol, 2);
            this.FormResol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.FormResol.Location = new System.Drawing.Point(3, 47);
            this.FormResol.Name = "FormResol";
            this.FormResol.Size = new System.Drawing.Size(226, 20);
            this.FormResol.TabIndex = 0;
            // 
            // DeskResol
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.DeskResol, 2);
            this.DeskResol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DeskResol.Location = new System.Drawing.Point(3, 135);
            this.DeskResol.Name = "DeskResol";
            this.DeskResol.Size = new System.Drawing.Size(226, 20);
            this.DeskResol.TabIndex = 1;
            // 
            // ResForm
            // 
            this.ResForm.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.ResForm, 2);
            this.ResForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ResForm.Location = new System.Drawing.Point(3, 0);
            this.ResForm.Name = "ResForm";
            this.ResForm.Size = new System.Drawing.Size(226, 44);
            this.ResForm.TabIndex = 2;
            this.ResForm.Text = "Разрешение Формы";
            this.ResForm.Click += new System.EventHandler(this.label1_Click);
            // 
            // DesForm
            // 
            this.DesForm.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.DesForm, 2);
            this.DesForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DesForm.Location = new System.Drawing.Point(3, 88);
            this.DesForm.Name = "DesForm";
            this.DesForm.Size = new System.Drawing.Size(226, 44);
            this.DesForm.TabIndex = 3;
            this.DesForm.Text = "Разрешение рабочего стола";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.DeskResol, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.ResForm, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.FormResol, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.DesForm, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(232, 176);
            this.tableLayoutPanel1.TabIndex = 4;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.Exit, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(232, 176);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // Exit
            // 
            this.Exit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Exit.Location = new System.Drawing.Point(50, 50);
            this.Exit.Margin = new System.Windows.Forms.Padding(50);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(132, 76);
            this.Exit.TabIndex = 0;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanelAll);
            this.MinimumSize = new System.Drawing.Size(300, 300);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanelAll.ResumeLayout(false);
            this.Place.ResumeLayout(false);
            this.Form.ResumeLayout(false);
            this.SizeForm.ResumeLayout(false);
            this.Resolution.ResumeLayout(false);
            this.GrExit.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelAll;
        private System.Windows.Forms.GroupBox Place;
        private System.Windows.Forms.GroupBox Form;
        private System.Windows.Forms.GroupBox SizeForm;
        private System.Windows.Forms.GroupBox Resolution;
        private System.Windows.Forms.GroupBox GrExit;
        private System.Windows.Forms.Button DownRight;
        private System.Windows.Forms.Button Down;
        private System.Windows.Forms.Button DownLeft;
        private System.Windows.Forms.Button Right;
        private System.Windows.Forms.Button Centre;
        private System.Windows.Forms.Button Left;
        private System.Windows.Forms.Button UpRight;
        private System.Windows.Forms.Button Up;
        private System.Windows.Forms.Button UpLeft;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button MaxWin;
        private System.Windows.Forms.Button Back;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button Resolution1000;
        private System.Windows.Forms.Button Resolution1200;
        private System.Windows.Forms.Button Ban;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Minus;
        private System.Windows.Forms.Button Standart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label DesForm;
        private System.Windows.Forms.Label ResForm;
        private System.Windows.Forms.TextBox FormResol;
        private System.Windows.Forms.TextBox DeskResol;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Button Exit;
    }
}

